package com.gupao.gpjvm;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GpJvmApplication {
	public static void main(String[] args) {
		SpringApplication.run(GpJvmApplication.class, args);
	}
}
